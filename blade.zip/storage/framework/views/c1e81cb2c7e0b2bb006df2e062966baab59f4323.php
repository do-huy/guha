<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="col-md-1"> 
      
    
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      
      <img style="width: 120px;height: 50px;padding-top: 9px" id="footerimg" src="<?php echo e(asset('img/express.png')); ?>" alt="">
    </div>
    </div>
     <div class="col-md-11"> 
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Trang chủ</a></li>
     
        <li><a href="#">Giới thiệu</a></li>
        <li><a href="#">Dịch vụ</a></li>
        <li><a href="#">Liên hệ</a></li>
        <li><a href="#">Bảng giá</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><i class="far fa-registered"></i> Đăng ký</a></li>
        <li><a href="#"><i class="fas fa-user-check"></i> Đăng nhập</a></li>
      </ul>
    </div>
  </div>
  </div>
</nav><?php /**PATH C:\xampp\htdocs\blade\resources\views/layouts/nav.blade.php ENDPATH**/ ?>